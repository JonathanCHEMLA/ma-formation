<?php

// Connexion à la base de données "exercice_3"
$dbh = new PDO('mysql:host=localhost;dbname=exercice_3;charset=utf8', 'root', '');
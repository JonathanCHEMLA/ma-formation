<?php

$pdo = new PDO('mysql: host=localhost;dbname=exercice_3_adnane', 'root', '',
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

echo '<pre>';
print_r($_POST);
echo '</pre>';

//echo '<pre>';
//print_r($_GET);
//echo '</pre>';

// L'ajout d'un Nouveau Film
if ($_POST) {

    // On vérifie si l'utilisateur remplie correctement les champs, on lui affiche un message dans le cas contraire
    $erreur = '';
    // $content .= $erreur;
    $ajout_movie = $pdo->prepare("SELECT * FROM movies WHERE title = :title");
    $ajout_movie->bindValue(':title', $_POST['title'], PDO::PARAM_STR);
    $ajout_movie->execute();
    echo $ajout_movie->rowCount();
    if ($ajout_movie->rowCount() >= 1) {
        $erreur .= '<div class="container alert alert-danger">Ce film existe déjà !</div>';
    }
    if (strlen($_POST['title']) < 5) {
        $erreur .= '<div class="container alert alert-danger">Trop court</div>';
    }
    if (strlen($_POST['director']) < 5) {
        $erreur .= '<div class="container alert alert-danger">Trop court</div>';
    }
    if (strlen($_POST['actors']) < 5) {
        $erreur .= '<div class=" container alert alert-danger">Trop court</div>';
    }

    if (strlen($_POST['producer']) < 5) {
        $erreur .= '<div class=" container alert alert-danger">Trop court</div>';
    }

    if (strlen($_POST['storyline']) < 5) {
        $erreur .= '<div class=" container alert alert-danger">Trop court</div>';
    }


    if (!filter_var($_POST['video'], FILTER_VALIDATE_URL)) {
        $erreur .= '<div class="container alert alert-danger">URL incorrect</div>';
    }


    // Si l'utilisateur à bien rempli les champs on insère le nouveaux film dans la BDD
    if (empty($erreur)) {


        $ajout_movie = $pdo->prepare("INSERT INTO movies(title, actors, director, producer, year_of_prod, language, category, storyline, video) 
    VALUES (:title, :actors, :director, :producer, :year_of_prod, :language, :category, :storyline, :video)");

        $ajout_movie->bindValue(':title', $_POST['title'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':actors', $_POST['actors'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':director', $_POST['director'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':producer', $_POST['producer'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':year_of_prod', $_POST['year_of_prod'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':language', $_POST['language'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':category', $_POST['category'], PDO::PARAM_STR);
        $ajout_movie->bindValue('storyline:', $_POST['storyline'], PDO::PARAM_STR);
        $ajout_movie->bindValue(':video', $_POST['video'], PDO::PARAM_STR);

        $ajout_movie->execute();

        $content .= '<div class="container alert alert-success">Le film a bien été ajouté ! 
                      </div>';
    }

}


?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
          integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Movies</title>
</head>
<body>

<div class="container">
    <form action="" method="post" enctype="multipart/form-data">
        <label for="title">Title</label>
        <input type="text" id="title" name="title">
        <br><br>

        <label for="actors">Actors</label>
        <input type="text" id="actors" name="actors">
        <br><br>


        <label for="director">Director</label>
        <input type="text" id="director" name="director">
        <br><br>


        <label for="producer">Producer</label>
        <input type="text" id="producer" name="producer">
        <br><br>


        <label for="yop">Year Of Production</label>
        <select type="text" id="yop" name="yop">
            <option value=""></option>
            <option value="">2018</option>
            <option value="">2017</option>
            <option value="">2016</option>
        </select>
        <br><br>


        <label for="language">Language</label>
        <select type="text" id="language" name="language">
            <option value=""></option>
            <option value="Français">Français</option>
            <option value="Anglais">Anglais</option>
            <option value="Espagnol">Espagnol</option>
        </select>
        <br><br>


        <label for="category">Category</label>
        <select name="category" id="category">
            <option value=""></option>
            <option value="Polar">Polar</option>
            <option value="Comedie">Comédie</option>
            <option value="Thriller">Thriller</option>
        </select>
        <br><br>


        <label for="synopsis">Synopsis</label>
        <textarea name="" id="" cols="30" rows="10"></textarea>
        <br><br>


        <label for="video">Video</label>
        <input type="text" id="video" name="video">
        <br><br>

        <button class="btn btn-primary" type="submit" value="">Ajout</button>

    </form>
</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>
</html>

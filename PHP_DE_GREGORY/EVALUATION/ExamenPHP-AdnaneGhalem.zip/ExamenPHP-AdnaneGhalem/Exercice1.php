<?php

// Date
$date = date("Y-m-d");
// echo $date;

// Création du tableau
$liste = array("Adnane", "Ghalem", "2 rue de La Paix", "75000", "Paris", "ghalemadnane@gmail.com", "0612345678",
    "Date de Naissance : $date");

// echo '<pre>'; print_r($liste); echo '</pre>';

// affichage liste HTML

foreach ($liste as $indice => $valeurs) {
    echo '<ul><li>' . $valeurs . '</li></ul>';
}


?>
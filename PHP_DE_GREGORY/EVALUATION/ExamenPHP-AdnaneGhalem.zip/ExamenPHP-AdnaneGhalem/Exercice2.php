<?php


function ConvertMoney($montant, $dollars = 1.085965)
{
    return $montant * $dollars;
}

echo ConvertMoney(10);

?>




<?php

echo'<pre>'; print_r($_POST); echo'</pre>';

if ($_POST)
{




echo 'Titre : ' . $_POST['title'] . '<br>';
echo 'Acteurs : ' . $_POST['actors'] . '<br>';
echo 'Directeur : ' . $_POST['director'] . '<br>';
echo 'Producteur : ' . $_POST['producer'] . '<br>';
echo 'Année de production : ' . $_POST['year_of_prod'] . '<br>';
echo 'Langue : ' . $_POST['language'] . '<br>';
echo 'Catégorie : ' . $_POST['category'] . '<br>';
echo 'Storyline : ' . $_POST['storyline'] . '<br>';
echo 'Vidéo : ' . $_POST['video'] . '<br>';


$erreur="";

if (iconv_strlen($_POST['title']) < 5 )  {
	 $erreur .= '<div style="background: red; padding:10px; color:#fff; width:200px; border-radius:5px">Merci de saisir un titre valide</div>';
}

if (iconv_strlen($_POST['director']) < 5 )  {
	 $erreur .= '<div style="background: red; padding:10px; color:#fff; width:200px; border-radius:5px">Merci de saisir un nom valide</div>';
}

if (iconv_strlen($_POST['actors']) < 5 )  {
	 $erreur .= '<div style="background: red; padding:10px; color:#fff; width:200px; border-radius:5px">Merci de saisir un nom valide</div>';
}

if (!filter_var($_POST['producer'] < 5) {
  	$erreur .= '<div style="background: red; padding:10px; color:#fff; width:200px; border-radius:5px">Merci de saisir un nom valide</div>';
} 

if (iconv_strlen($_POST['synopsis']) < 5  >20)
{
	$erreur .='<div style="background: red; padding:10px; color:#fff; width:200px; border-radius:5px">Merci de saisir un synopsis valide</div>';
}

if (iconv_strlen($_POST['synopsis']) < 5  >20)
{
	$erreur .='<div style="background: red; padding:10px; color:#fff; width:200px; border-radius:5px">Merci de saisir un synopsis valide</div>';
}




?>



if(isset($_GET['action']) && $_GET ['action'] == 'ajout')

	if(empty($erreur)) 
			{
			$resultat = $pdo-> prepare  (" INSERT INTO movies (titre, acteurs,  directeur, producteur, année de production, langue, categorie, storyline, vidéo) VALUES (:title, :actors, :director, :year_of_prod, :language, :category, :storyline, :video)");

			$content .='<div class="alert alert-success col-md-8 col-md-offset-2 text-center">Le film <span class="text-success">' . $_POST['reference'] . ' </span> a bien été ajouté</div>';
			}




?>

<!-- creation du formulaire d'ajout de films -->
<!DOCTYPE html>
<html>
<head>
	<title>Formulaire 2</title>
	<style>
		label{
			float: left;
			width: 95px;
			font-style: italic;
			font-family: Calibri;
		}
	</style>
</head>
<body>
	<h1> Ajouter un film </h1>
	<hr>
	<br>
	<form method="post" action="">

		<label for ="titre">Titre</label>
		<input type="text" id="titre" name="title" placeholder="titre">
		<br><br> 

		<label for ="acteurs">Acteurs</label>
		<input type="text" id="acteurs" name="actors" placeholder="acteurs" >	
		<br><br>

		<label for ="directeur">Directeur</label>
		<input type="text" id="directeur" name="director" placeholder="directeur" ><br><br>	
		<br><br>

		<label for ="producteur">Producteur</label>
		<input type="text" id="producteur" name="producer" placeholder="producteur" >	
		<br><br>

		<label for ="email">Année de production</label>
		<input type="date" name=" year_of_prod">	
		<br><br>

		<label for ="langue">Langue</label>
		<select name=" language">	
			<option value>Anglais</option>
			<option value>Français</option>
			<option value>Autres</option>
		</select>
		<br><br>

		<label for ="categorie">Catégorie</label>
		<select name="category">	
			<option value>Action</option>
			<option value>Drame</option>
			<option value>Humour</option>
			<option value>Autres</option>
		</select>
		<br><br>

		<label for ="storyline">Storyline</label>
		<input type="text" id="storyline" name="storyline" placeholder="storyline" ><br><br>	
		<br><br>

		<label for ="video">Vidéo</label>
		<input type="url" id="video" name="video" placeholder="http://www.example.com" required><br><br>	<!-- url est ici obligatoirement requis-->
		<br><br>
		
		<input type="submit" value="submit">
</body>
</html>
<?php
// creation du tableau
$identite = array (
	'Prénom' => 'Hana', 
	'Nom' => 'Mattei', 
	'Adresse' =>'59 rue de dunkerque' , 
	'Code Postal' => '75009', 
	'Ville' => 'Paris', 
	'Email' => 'hana.mattei@gmail.com', 
	'Téléphone' => '0678731641', 
	"Date de naissance" =>'1988/12/10'
);
// affichage du tableau avec la boucle
foreach ($identite as $indice => $valeur) 
{
	echo "$indice  : $valeur" . '<br>'; 
}



?>
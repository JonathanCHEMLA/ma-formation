<?php
/*function convertir($montant)
{
	return $montant * 1.085965;
}
echo convertir('20');*/




/*function convertir($montant, $devise) 
{
	echo " $montant . euro = $montant . USD";
	if ($montant == float || $montant == integer  && $devise == EUR ) 
	{
		return $resultat = $montant * 1.085965;
		echo convertir('20', $devise);
		 
	}
	else
	{
		echo " erreur de montant ou devise";
	}
	echo convertir('20', $devise);
 

}

?>*/

function convertir($montant, $devise) // creation de la fonction avec les parametres
{  
  	
    if ( is_numeric($montant) || $devise == 'EUR' || $devise == 'USD' ) // expression des conditions
    {            
       return $resultat = $montant * 1.085965 . '<br>' ;
     }
     else 
     {
     	 return 'erreur montant ou devise'; // affichage du message d'erreur
    }       
} 

echo convertir(5, 'EUR'); // affichage de la conversion

?>

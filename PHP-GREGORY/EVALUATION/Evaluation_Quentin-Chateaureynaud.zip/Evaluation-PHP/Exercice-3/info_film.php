<?php
    require_once("inc/init.inc.php");
    if(isset($_GET['id_film']))
    {
        $verif_film = $pdo->prepare("SELECT * FROM movies WHERE id_film = :id_film");
        $verif_film->bindValue(':id_film', $_GET['id_film'], PDO::PARAM_STR);
        $verif_film->execute();




        $film = $verif_film->fetch(PDO::FETCH_ASSOC);
        // print_r($film);
        if($verif_film->rowCount() < 1)
        {
            die('<h1>Erreur, le film demandé n\'existe plus ou n\'existe pas<h1>');
        }
    }
    require_once("inc/header.php");
    
?>

<div class="col-md-12">
    <div class="panel-default bordertext">
        <div class="panel-heading text-center"><h2><?= $film['title']?></h2></div>
        <div class="panel-body">
            <div class="col-xs-12">
            <iframe width="560" height="315" 
            src="<?= "$film[video]" ?>">
            </iframe>
            </div>
            <div class="col-xs-12 text-left">
                <p><span class="titresec">Producteur : </span><?= $film['producer']; ?><p>
                <p><span class="titresec">Réalisateur : </span><?= $film['director']; ?><p>
                <p><span class="titresec">Acteurs : </span><?= $film['actors']; ?><p>
                <p><span class="titresec">Date de production : </span><?= $film['year_of_prod'].'<br>'?><p>
                <p><span class="titresec">Categorie : </span><?= $film['category']; ?><p>
                <p><span class="titresec">Langue : </span><?= $film['language'].'<br>'?> <p>
                <p><span class="titresec">Synopsis : </span><?= $film['storyline']; ?><p>
            </div>
        </div>
        </div>
    </div>
</div>

<?php
    require_once("inc/footer.php");
?>
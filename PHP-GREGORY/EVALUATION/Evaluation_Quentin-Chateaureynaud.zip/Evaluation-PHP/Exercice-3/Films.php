
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Films</title>
</head>
<body>
    <?php
        require_once("inc/header.php");
        require_once("inc/init.inc.php");

        echo'<h1 class="alert alert-info text-center">Listes Des Films</h1>';

        $resultat = $pdo->query("SELECT * FROM movies");
        echo '<table class="table">';
        echo '<th class="text-center">Titre</th><th class="text-center">Directeur</th><th class="text-center">Année de production</th><th class="text-center">Info</th>';
        while($films = $resultat->fetch(PDO::FETCH_ASSOC)){
            echo '<tr>';
            foreach ($films as $key => $value) {
                if($key != "id_film" && $key != "actors" && $key != "producer" && $key != "language" && $key != "category" && $key != "storyline" && $key != "video"){
                echo "<td class='text-center'>$value</td>";
                }
                if($key == "id_film"){
                    echo '<td class="text-center"><a href="info_film.php?id_film='.$value.'" ALT="">Plus d\'informations</a></td>';
                }
            }
            echo '</tr>';
        }
        echo '</table>';

    ?>
<?php
    require_once("inc/footer.php");
?>









































<?php
//  ========== CONNEXION BDD

$pdo = new PDO('mysql:host=localhost;dbname=exercice_3','root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

// =========== SESSION
session_start();

// =========== CHEMIN
define("RACINE_SITE",$_SERVER['DOCUMENT_ROOT']."/Evaluation-PHP/");
// cette constante retourne le chemin physique du dossier boutique sur le serveur : lors de l'enregistrement d'image/photo, nous aurons besoin du chemin complet du dossier photo pour enregistrer la photo
// echo '<pre>';print_r($_SERVER);'</pre>';
// echo RACINE_SITE;

define("URL", 'http://localhost/Evaluation-PHP/'); // Cette constante servira a enregistrer l'url d'une photo/image dans la BDD, on ne conserve jamais la photo elle meme, ce serai trop lourd pour la BDD

// =========== VARIABLES
$content = '';

// =========== INCLUSIONS
require_once("function.php");

?>
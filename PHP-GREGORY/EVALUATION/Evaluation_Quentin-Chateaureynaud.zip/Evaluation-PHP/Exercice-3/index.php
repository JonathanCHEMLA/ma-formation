<?php
require_once("inc/init.inc.php");


$membre = array(
    "Prénom" => "Quentin",
    "Nom" => "Chateaureynaud",
    "Adresse" => "2 rue des poireaux",
    "Code Postal" => "78000",
    "Ville" => "JsPark",
    "Email" => "quentin78480@yahoo.fr",
    "Téléphone" => "0611111111",
    "Date_de_naissance" => "2010-10-10",

);
// print_r($membre);


// echo '<ul>';
// foreach ($membre as $key => $value) {
//     if($key != 'Date_de_naissance'){
//         echo "<li>$key : $value</li>";
//     }
//     else
//     {
//         $date = new DateTime("$value");
//         $date = $date->format('d-m-Y');
//         echo "<li>$key : $date</li>";
//     }
// }
// echo '</ul>';



if($_POST)
{
    // print_r($_POST);
    $erreur = "";
    if(iconv_strlen($_POST['title']) < 5){
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du titre invalide !</div>';
    }
    if(iconv_strlen($_POST['director']) < 5){
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du nom du réalisateur invalide !</div>';
    }
    if(iconv_strlen($_POST['producer']) < 5){
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du producteur invalide !</div>';
    }
    if(iconv_strlen($_POST['actors']) < 5){
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille des acteurs invalide !</div>';
    }
    if(iconv_strlen($_POST['storyline']) < 5){
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du synopsis invalide !</div>';
    }
    if(empty($_POST['year_of_prod']))
    {
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Veuillez choisir une année !</div>';
    }
    if(empty($_POST['language']))
    {
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Veuillez choisir une langue !</div>';
    }
    if(empty($_POST['category']))
    {
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Veuillez choisir une catégorie !</div>';
    }
    if(!url_exists($_POST['video'])){
        $erreur .='<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Veuillez entrer une URL valide !</div>';
    }
    $content .= $erreur;
    if(empty($erreur))
    {
        $ajout_film = $pdo->prepare("INSERT INTO movies (title, actors, director, producer, year_of_prod, language, category, storyline, video) VALUES (:title,:actors,:director,:producer,:year_of_prod,:language,:category,:storyline,:video)");
        $ajout_film->bindValue(':title', $_POST['title'], PDO::PARAM_STR);
        $ajout_film->bindValue(':actors', $_POST['actors'], PDO::PARAM_STR);
        $ajout_film->bindValue(':director', $_POST['director'], PDO::PARAM_STR);
        $ajout_film->bindValue(':producer', $_POST['producer'], PDO::PARAM_STR);
        $ajout_film->bindValue(':year_of_prod', $_POST['year_of_prod'], PDO::PARAM_STR);
        $ajout_film->bindValue(':language', $_POST['language'], PDO::PARAM_STR);
        $ajout_film->bindValue(':category', $_POST['category'], PDO::PARAM_STR);
        $ajout_film->bindValue(':storyline', $_POST['storyline'], PDO::PARAM_STR);
        $ajout_film->bindValue(':video', $_POST['video'], PDO::PARAM_STR);
        $ajout_film->execute();
        $content .='<div class="alert alert-success col-md-8 col-md-offset-2 text-center">Votre film a bien été enregistré ! <a href="Films.php" class="alert-link">Cliquez ici</a> pour aller voir la liste des films</div>';
    }

}

require_once("inc/header.php");
echo $content;
?>



<body>
    <h1>Ajout de films</h1>
    
    <form action="" method="post">
    <div class="form-group">
        <label for="title">Titre</label>
        <input type="text" class="form-control" name="title" id="title" placeholder="Titre"><br>
        <label for="director">Nom du réalisateur</label>
        <input type="text" class="form-control" name="director" id="director" placeholder="Réalisateur"><br>
        <label for="actors">Acteurs</label>
        <input type="text" class="form-control" name="actors" id="actors" placeholder="Acteurs"><br>
        <label for="producer">Producteur</label>
        <input type="text" class="form-control" name="producer" id="producer" placeholder="Producteur"><br>
        <label for="storyline">Synopsis</label>
        <textarea type="text" class="form-control" name="storyline" id="storyline" placeholder="Synopsis"></textarea><br>
        <label for="year_of_prod">Année de production</label>
        <select name="year_of_prod" class="form-control" id="year_of_prod">
            <option value="">-- Année --</option>
            <option value="2018">2018</option>
            <option value="2017">2017</option>
            <option value="2016">2016</option>
            <option value="2015">2015</option>
            <option value="2015">2014</option>
            <option value="2015">2013</option>
            <option value="2015">2012</option>
            <option value="2015">2011</option>
            <option value="2015">2010</option>
            <option value="2015">2009</option>
            <option value="2015">2008</option>
            <option value="2015">2007</option>
            <option value="2015">2006</option>
            <option value="2015">2005</option>
            <option value="2015">2004</option>
            <option value="2015">2003</option>
            <option value="2015">2002</option>
            <option value="2015">2001</option>
            <option value="2015">2000</option>
        </select><br><br>
        <label for="language">Langue</label>
        <select name="language" class="form-control" id="language">
            <option value="">-- Langue --</option>
            <option value="fr">Français</option>
            <option value="an">Anglais</option>
            <option value="al">Allemand</option>
            <option value="jp">Japonnais</option>
            <option value="ru">Russe</option>
        </select><br>
        <label for="category">Catégorie</label>
        <select name="category" class="form-control" id="category">
            <option value="">-- Catégorie --</option>
            <option value="Action">Action</option>
            <option value="Aventure">Aventure</option>
            <option value="Comedie">Comedie</option>
            <option value="Horreur">Horreur</option>
        </select><br>
        <label for="video">Vidéo</label>
        <input type="url" class="form-control" name="video" id="video" placeholder="URL"><br><br>
        <input type="submit" class="btn btn-primary col-xs-12" value="Ajouter" name="ajouter" id="ajouter">
    </div>
    </form>

</body>








<?php
require_once("inc/footer.php");

?>
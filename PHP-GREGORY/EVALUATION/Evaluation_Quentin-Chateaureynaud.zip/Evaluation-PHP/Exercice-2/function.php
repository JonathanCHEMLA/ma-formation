<?php
// --------------  Convertisseur $ en €  -----------------
function convertisseur($montant, $devise)
{
    if(is_numeric($montant)){
        if($devise == "EUR")
        {
            return $resultat = $montant*0.807145;
        }
        elseif ("USD")
        {
            return $resultat = $montant*1.23893;
        }
    }
}
// echo convertisseur(72,"EUR");


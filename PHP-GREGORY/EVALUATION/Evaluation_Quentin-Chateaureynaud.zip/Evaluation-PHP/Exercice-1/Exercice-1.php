<?php

$membre = array(
    "Prénom" => "Quentin",
    "Nom" => "Chateaureynaud",
    "Adresse" => "2 rue des poireaux",
    "Code Postal" => "78000",
    "Ville" => "JsPark",
    "Email" => "quentin78480@yahoo.fr",
    "Téléphone" => "0611111111",
    "Date_de_naissance" => "2010-10-10",

);
// print_r($membre);


echo '<ul>';
foreach ($membre as $key => $value) {
    if($key != 'Date_de_naissance'){
        echo "<li>$key : $value</li>";
    }
    else
    {
        $date = new DateTime("$value");
        $date = $date->format('d-m-Y');
        echo "<li>$key : $date</li>";
    }
}
echo '</ul>';

















<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <title>Evaluation</title>
</head>
<body>

<?php

/*
    Étape 3 :
    Créer une page listant dans un tableau HTML les films présents dans la base de données.
    Ce tableau ne contiendra, par film, que le nom du film, le réalisateur et l’année de
    production.
    Une colonne de ce tableau contiendra un lien « plus d’infos » permettant de voir la fiche
    d’un film dans le détail.
*/

// On se connecte à la BDD
$pdo = new PDO('mysql:host=localhost;dbname=exercice_3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

// 
$resultat = $pdo->query("SELECT * FROM movies"); // on va chercher les infos qui nous intéressent dans la base de données

echo '<div class="alert alert-success col-md-10 col-md-offset-1 text-center"><h3>Liste des films</h3></div>'; // titre


echo '<table class="table"><tr>';
for($i = 0; $i < $resultat->columnCount(); $i++) // on boucle tant qu'il y a des colonnes
if($i == 1 OR $i == 3 OR $i == 5) // on affiche seulement le nom du film, le réalisateur et l’année de production.
{
    $colonne = $resultat->getColumnMeta($i); // on récolte les informations des champs/colonnes de la table, pour chaque tour de booucle
    echo '<td><strong>' . $colonne['name'] . '</strong></td>'; // on va crocheter à l'indice 'name' pour afficher le nom des colonnes
}
else // si ce n'est pas le nom du film, le réalisateur ou l’année de production on affiche rien
{
    echo '';
}
echo '<td><strong>En savoir plus</strong></td>'; // on créé la colonne plus dinfo
echo '</tr>';
while($informations = $resultat->fetch(PDO::FETCH_ASSOC)) // on associe la méthode fetch() au résultat, $informations contient un tableau ARRAY avec les informations d'un employé à chaque tour de boucle
    {
        echo '<tr>'; // on crée une nouvelle ligne pour chaque film
        foreach($informations as $indice => $valeur) // on collecte les infos pour chaque film
        {
        if($indice == 'title' OR $indice == 'director' OR $indice == 'year_of_prod') // on affiche seulement le nom du film, le réalisateur et l’année de production.
        {
            echo "<td>$valeur</td>"; // on affiche les valeur dans les cellules a chaque tour de boucle
        }
        else // si ce n'est pas le nom du film, le réalisateur ou l’année de production on affiche rien
        {
            echo "";
        }
    }
    echo '<td><a href="details.php?id_movie=' . $informations['id_movie'] . '"><i class="fas fa-edit"></i>Plus d\'infos</a></td>'; // on créé la cellule plus d'info pour chaque film avec son id propre
    echo '</tr>';
    }
echo '</table>';

?>
</body>
</html>
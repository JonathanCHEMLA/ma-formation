-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 08 mars 2018 à 14:06
-- Version du serveur :  10.1.26-MariaDB
-- Version de PHP :  7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `exercice_3`
--

-- --------------------------------------------------------

--
-- Structure de la table `movies`
--

CREATE TABLE `movies` (
  `id_movie` int(3) NOT NULL,
  `title` varchar(80) NOT NULL,
  `actors` varchar(40) NOT NULL,
  `director` varchar(40) NOT NULL,
  `producer` varchar(40) NOT NULL,
  `year_of_prod` year(4) NOT NULL,
  `language` varchar(30) NOT NULL,
  `category` enum('comedie','action','horreur','thriller','fantasy') NOT NULL,
  `storyline` text NOT NULL,
  `video` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `movies`
--

INSERT INTO `movies` (`id_movie`, `title`, `actors`, `director`, `producer`, `year_of_prod`, `language`, `category`, `storyline`, `video`) VALUES
(1, 'Le seigneur des anneaux : la communauté de l\'anneau', 'Elijah Wood', 'Peter Jackson', 'Miramax Films', 2001, 'Anglais', 'comedie', 'rthrfthrthrth', 'http://www.allocine.fr/video/player_gen_cmedia=19448550&cfilm=27070.html'),
(2, 'Le seigneur des anneaux : les deux tours', 'Elijah Wood, Ian McKellen, Viggo Mortens', 'Peter Jackson', 'Miramax Films', 2003, 'Anglais', 'thriller', 'SAURON ENCORE PAS CONTENT', 'http://www.allocine.fr/video/player_gen_cmedia=19448598&cfilm=39186.html'),
(3, 'Le seigneur des anneaux : le retour du roi', 'Elijah Wood, Sean Astin, Viggo Mortensen', 'Peter Jackson', 'Miramax Films', 2003, 'Anglais', 'thriller', 'Les armées de Sauron ont attaqué Minas Tirith, la capitale de Gondor. Jamais ce royaume autrefois puissant n\'a eu autant besoin de son roi. Mais Aragorn trouvera-t-il en lui la volonté d\'accomplir sa destinée ?', 'http://www.allocine.fr/video/player_gen_cmedia=19448603&cfilm=39187.html');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id_movie`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `movies`
--
ALTER TABLE `movies`
  MODIFY `id_movie` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

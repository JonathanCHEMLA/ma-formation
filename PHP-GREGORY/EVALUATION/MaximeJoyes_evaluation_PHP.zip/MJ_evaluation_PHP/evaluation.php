<?php
//----------------- EXERCICE 1

    /* Créer un tableau en PHP contenant les infos suivantes :
    ● Prénom
    ● Nom
    ● Adresse
    ● Code Postal
    ● Ville
    ● Email
    ● Téléphone
    ● Date de naissance au format anglais (YYYY-MM-DD)
    */
    // création de la date :
    $date = new DateTime('1993-04-27');

    $mesinfos = array(
        'prenom'      => 'Maxime',
        'nom'         => 'Joyes',
        'adresse'     => '115 rue de reuilly',
        'code_postal' => 75012,
        'ville'       => 'Paris',
        'email'       => 'maxime.joyes@gmail.com',
        'telephone'   => '06 58 21 13 66',
        'birthdate'   => $newDate = $date->format('d/m/Y'), // mise au format français de la date
    );

    // A l’aide d’une boucle, afficher le contenu de ce tableau (clés + valeurs) dans une liste HTML.
    // La date sera affichée au format français (DD/MM/YYYY).

    echo '<h1>Exercice 1 : « On se présente ! »</h1>';
    echo '<ul>'; // création de la liste ul
    foreach($mesinfos as $key => $valeur) // on boucle sur chaque indice => valeur du tableau
    {
        echo '<li>' . $key . ' : ' . $valeur . '</li>'; // j'affiche l'indice suivi de la valeur pour chaque tour de boucle
    }
    echo '</ul>'; // je ferme la liste ul quand la boucle s'arrete
    echo '<hr><br>';


//----------------- EXERCICE 2
echo '<h1>Exercice 2 : « On part en voyage »</h1>';

// Créer une fonction permettant de convertir un montant en euros vers un montant en dollars américains.

function convertisseur($entier_float,$devise) // création de la fonction nom(paramtre 1, parametre 2)
{
    if($devise === 'USD') // si la devise choisi est dollar alors on convertit de euro à dollars
    {
        $resultat = $entier_float*1.085965; // le calcul pour la conversion
        echo $entier_float . ' euros = ' . $resultat .  ' dollars américains'; // on affiche le résultat
    }
    if($devise === 'EUR') // si la devise choisi est dollar alors on convertit de dollars à euros
    {
        $resultat = $entier_float*0.914035;
        echo $entier_float . ' dollars = ' . $resultat .  ' euros';
    }
}


echo convertisseur(1,'USD'); // appel de la fonction
echo '<hr><br>';


//----------------- EXERCICE 3
echo '<h1>Exercice 3 : « Et si on regardait un film ? »</h1>';

/*
Étape 1 :
TABLE MOVIES :
● id_movie (INT) : ID du film
● title (varchar) : le nom du film
● actors (varchar) : les noms d’acteurs
● director (varchar) : le nom du réalisateur
● producer (varchar) : le nom du producteur
● year_of_prod (year) : l’année de production
● language (varchar) : la langue du film
● category (enum) : la catégorie du film
● storyline (text) : le synopsis du film
● video (varchar) : le lien de la bande annonce du film
*/

// Étape 2 :
// Créer un formulaire permettant d’ajouter un film et effectuer les vérifications nécessaires
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <title>Evaluation</title>
</head>
<body>
    <form method="post" action="" class="col-md-4 col-md-offset-4">
        <h1 class="alert alert-info text-center">Ajouter un film</h1>
        
        <div class="form-group">
            <label for="title">Titre</label>
            <input type="text" class="form-control" id="title" name="title" placeholder="titre">
        </div>
        <div class="form-group">
            <label for="actors">Acteurs</label>
            <input type="text" class="form-control" id="actors" name="actors" placeholder="acteurs">
        </div>
        <div class="form-group">
            <label for="director">Nom du réalisateur</label>
            <input type="text" class="form-control" id="director" name="director" placeholder="nom du réalisateur">
        </div>
        <div class="form-group">
            <label for="producer">Producteur</label>
            <input type="text" class="form-control" id="producer" name="producer" placeholder="producteur">
        </div>
        <div class="form-group">
            <label for="year_of_prod">Année de production</label>
            <select class="form-control" name="year_of_prod">
                <option>1990</option>
                <option>1991</option>
                <option>1992</option>
                <option>1993</option>
                <option>1994</option>
                <option>1995</option>
                <option>1996</option>
                <option>1997</option>
                <option>1998</option>
                <option>1999</option>
                <option>2000</option>
                <option>2001</option>
                <option>2002</option>
                <option>2003</option>
                <option>2004</option>
                <option>2005</option>
            </select>
        </div>
        <div class="form-group">
            <label for="language">Langue</label>
            <select class="form-control" name="language">
                <option>Anglais</option>
                <option>Français</option>
            </select>
        </div>
        <div class="form-group">
            <label for="category">Categorie</label>
            <select class="form-control" name="category">
                <option value="comedie">Comédie</option>
                <option value="horreur">Horreur</option>
                <option value="action">Action</option>
                <option value="thriller">Thriller</option>
                <option value="thriller">Fantasy</option>
            </select>
        </div>
        <div class="form-group">
            <label for="storyline">Synopsis</label>
            <textarea type="text" class="form-control" id="storyline" name="storyline" placeholder="le synopsis du film"></textarea>
        </div>
        <div class="form-group">
            <label for="video">Lien de la bande annonce</label>
            <input type="text" class="form-control" id="video" name="video" placeholder="URL de la bande annonce">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Ajouter</button>
    </form>
        
</body>
</html>

<?php
$content = ""; // on crée une variable content vide pour afficher un message success si tout fonctionne
$erreur = ""; // on crée une variable erreur vide qu'on pourra remplir en fonction de l'erreur
if($_POST)
{
if(iconv_strlen($_POST["title"]) < 5) // si le champ ne contient pas 5 caractères on rempli la variable erreurd'un message d'erreur
{
	$erreur .= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Le nom du film doit comporter au minimum 5 caractères.</div>';
}
if(iconv_strlen($_POST["director"]) < 5) // si le champ ne contient pas 5 caractères on rempli la variable erreurd'un message d'erreur
{
	$erreur .= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Le nom du réalisateur doit comporter au minimum 5 caractères.</div>';
}
if(iconv_strlen($_POST["actors"]) < 5) // si le champ ne contient pas 5 caractères on rempli la variable erreurd'un message d'erreur
{
	$erreur .= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Le champ nom acteurs doit comporter au minimum 5 caractères.</div>';
}
if(iconv_strlen($_POST["producer"]) < 5) // si le champ ne contient pas 5 caractères on rempli la variable erreurd'un message d'erreur
{
	$erreur .= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Le champ producteur doit comporter au minimum 5 caractères.</div>';
}
if(iconv_strlen($_POST["storyline"]) < 5) // si le champ ne contient pas 5 caractères on rempli la variable erreurd'un message d'erreur
{
	$erreur .= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Le champ synopsis doit comporter au minimum 5 caractères.</div>';
}
if(!filter_var($_POST["video"], FILTER_VALIDATE_URL)) // on vérifie l'URL grâce à la fonction filter_var() avec FILTER_VALIDATE_URL parametre
{
	$erreur .= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Ce n\'est pas un URL valide</div>';
}

// On se connecte à la BDD
$pdo = new PDO('mysql:host=localhost;dbname=exercice_3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

if(empty($erreur)) // // On prepare la requete d'insertion si la variable $erreur est vide (cela veut dire que les champs ont correctement été rempli)
    {
        $resultat = $pdo->prepare("INSERT INTO movies (title, actors, director, producer, year_of_prod, language, category, storyline, video) VALUES (:title,:actors,:director,:producer,:year_of_prod,:language,:category,:storyline,:video)"); // on prépare la requete avec des marqueurs nominatifs,
        $resultat->bindValue(':title', $_POST['title'], PDO::PARAM_STR); // on associe une nouvelle valeur au marqueur
        $resultat->bindValue(':actors', $_POST['actors'], PDO::PARAM_STR);
        $resultat->bindValue(':director', $_POST['director'], PDO::PARAM_STR);
        $resultat->bindValue(':producer', $_POST['producer'], PDO::PARAM_STR);
        $resultat->bindValue(':year_of_prod', $_POST['year_of_prod'], PDO::PARAM_INT);
        $resultat->bindValue(':language', $_POST['language'], PDO::PARAM_STR);
        $resultat->bindValue(':category', $_POST['category'], PDO::PARAM_STR);
        $resultat->bindValue(':storyline', $_POST['storyline'], PDO::PARAM_STR);
        $resultat->bindValue(':video', $_POST['video'], PDO::PARAM_STR);
        $resultat->execute(); // execution de la requête
        $content .= '<div class="alert alert-success col-md-8 col-md-offset-2 text-center">Le film : <span class="text-success">' . $_POST['title'] . '</span> à bien été enregistré dans la base de données MOVIES.</div>'; // afficher un message quand le film est ajouté
    }
}
echo $content .= $erreur;
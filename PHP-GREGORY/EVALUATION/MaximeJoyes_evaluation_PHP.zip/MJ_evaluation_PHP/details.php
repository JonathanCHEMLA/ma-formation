<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <title>Evaluation</title>
</head>
<body>

<?php
//echo '<pre>'; print_r($_GET); echo '</pre>';
/*
    Étape 4 :
    Créer une page affichant le détail d’un film de manière dynamique. Si le film n’existe pas,
    une erreur sera affichée. 
*/



// afficher le détail d’un film de manière dynamique
if(isset($_GET['id_movie'])) // on vérifie que les ifnos sont bien dans l'url
{
// On se connecte à la BDD
    $pdo = new PDO('mysql:host=localhost;dbname=exercice_3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

    echo '<div class="alert alert-success col-md-10 col-md-offset-1 text-center"><h3>Détail du film</h3></div><br><br><br><br><br>'; // titre
    $resultat = $pdo->prepare("SELECT * FROM movies WHERE id_movie = :id_movie"); // on va chercher les infos du film en fonction de son ID
    $resultat->bindValue(':id_movie', $_GET['id_movie'], PDO::PARAM_INT); // on remplace :id_movie par la valeur de id movie dans le $_GET['id_movie']
    $resultat->execute(); // on execute la requete
    if($resultat->rowCount() > 0) // vérifie que la requete trouve l'ID et on affiche les details du film
    {
        $details = $resultat->fetch(PDO::FETCH_ASSOC); // on associe la méthode fetch() pour rendre le résultat exploitable
        echo '<div class="container">';
        echo '<ul class="list-group">'; // on ouvre la liste ul
        foreach($details as $indice => $valeur) // on boucle sur les données du film
        {
            if($indice == 'id_movie') // si l'indice est id_movie
            {
                echo ''; // on affiche pas l'id_movie qui n'interesse pas l'utilisateur
            }
            elseif($indice == 'video') // si l'indice est video
            {
                echo '<li class="list-group-item">' . $indice . ' : <a href="' . $valeur . '">' . $valeur . '</a></li>'; // on met un url pour aller vers la bande annonce
            }
            else
            {
                echo '<li class="list-group-item">' . $indice . ' : ' . $valeur . '</li>'; // on affiche les données à chaque tour de boucle
            }
        }
        echo '</ul></div>'; // on ferme la liste ul
    }
    else
    {
        echo '<div class="alert alert-danger col-md-10 col-md-offset-1 text-center"><h3>Ce film n\'existe pas dans notre BDD</h3></div>'; // si l'ID n'existe pas on affiche un message d'erreur
    }
}
else
{
    header("location:liste_film.php"); // si il n'y a pas de $_GET on renvoit l'utilisateur choisir un film dans la liste
}
?>

</body>
</html>
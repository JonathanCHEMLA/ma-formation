<?php
require_once("inc/init.inc.php");

require_once("inc/header.inc.php");
?>

<?php
//Etape 1:
//Réalisée depuis PHP-MYADMIN
?>


<?php
require_once("inc/footer.inc.php");
?>	
	

CREATE TABLE movies (
  id_title int(10) NOT NULL AUTO_INCREMENT,
  actors varchar(30) NOT NULL,
  director varchar(30) NOT NULL,
  producer varchar(10) NOT NULL,
  year_of_prod date NOT NULL,
  language varchar(30) NOT NULL,
  category varchar(30) NOT NULL,
  storyline int(50) NOT NULL,
  video varchar(255) NOT NULL,
  description text NOT NULL,
  PRIMARY KEY (id_annuaire)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
<?php
$pdo = new PDO('mysql:host=localhost;dbname=exercice_3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

if($_POST)
{
	$resultat = $pdo->exec("INSERT INTO movies (title, actors, director, producer, year_of_prod, language, category, storyline, video ) VALUES ('$_POST[title]', '$_POST[actors]','$_POST[director]','$_POST[producer]','$_POST[year_of_prod]','$_POST[language]','$_POST[category]','$_POST[storyline]','$_POST[video]')");
	
	echo '<div style="background: green; padding: 10px; text-align: center; border-radius: 5px; width: 200px;">Inscription OK!!</div>';
}

?>
<!DOCTYPE html>
<html>
	<head>
		<style>
			label{
				float: left;
				width: 120px;
				font-style: italic;
				font-family: Calibri;
			}
		</style>
	</head>
	<body>
		<h1>Ajout d'un film</h1>
		<hr>
		<form method="post" action="">
			<label for="title">title</label>
			<input type="text" id="title" name="title" placeholder="title"><br><br>
			
			<label for="actors">actors</label>
			<input type="text" id="actors" name="actors" placeholder="actors"><br><br>
			
            <label for="director">director</label>
			<input type="text" id="director" name="director" placeholder="director"><br><br>
            
            <label for="producer">producer</label>
			<input type="text" id="producer" name="producer" placeholder="producer"><br><br>

            <label for="year_of_prod">year_of_prod</label>
			<input type="date" id="year_of_prod" name="year_of_prod" placeholder="year_of_prod"><br><br>
			
			<label for="language">language</label>
			<input type="text" id="language" name="language" placeholder="language"><br><br>
			
			<label for="category">category</label>
			<input type="text" id="category" name="category" placeholder="category"><br><br>
				
			<label for="storyline">storyline</label>
			<input type="text" id="storyline" name="storyline" placeholder="storyline"><br><br>

            <label for="video">video</label>
			<input type="text" id="video" name="video" placeholder="video"><br><br>
			
			<input type="submit" value="inscription">
		</form>
	</body>
</html>

<style>
    p{
        margin: 0;
        font-size: 15px;
        background: #dedede;
        text-align: center;
        padding: 10px;
    }
</style>
<?php
echo "<p>On se présente</p><hr>";
$tab_multi = array(
    0 => array("prenom" => "John", "nom" => "Garcia", "adresse" => "malassis", "code_postal" => "94400", "ville" => "Vitry", "email" => "John@hotmail.fr", "telephone" => "0000000000", "date_de_naissance" => "14-12-1992"),
);
foreach($tab_multi as $indice1 => $tableau)
{
    foreach($tableau as $indice2 => $valeurs)
    {
        echo $valeurs . '<br>';
    }
    echo'<hr>';
}

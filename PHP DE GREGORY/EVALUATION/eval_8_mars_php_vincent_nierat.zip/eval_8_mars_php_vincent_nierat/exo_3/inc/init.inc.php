<?php

//  ========== CONNEXION BDD
$pdo = new PDO('mysql:host=localhost;dbname=exercice_3','root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

// =========== SESSION
session_start();

// =========== CHEMIN
define("RACINE_SITE",$_SERVER['DOCUMENT_ROOT']."/eval_8_mars_php/exo_3/");
// Cette constante retourne le chemin physique du dossier boutique sur le serveur;
// echo '<pre>';print_r($_SERVER);'</pre>';
// echo RACINE_SITE;


// =========== VRAIABLES
$content= '';


// =========== INCLUSIONS
require_once("fonction.inc.php");
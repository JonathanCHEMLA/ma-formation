<?php

require_once('inc/init.inc.php');

// Créer un tableau listant les films
if(isset($_GET['action']) && $_GET['action'] == 'affichage')
    {  
        echo'
       <div class="col-md-8">
       <div class="col-md-12 col-md-offset-2">
       <h2 class="text-center alert alert-info">Liste des film</h2>
       </div>
           <table class="table">
                   <tr><th class="text-center">id membre</th><th class="text-center">Pseudo</th><th class="text-center">Mdp</th>
                   <th>Nom</th><th class="text-center">Film</th><th class="text-center">Réalisateur</th><th class="text-center">Année</th><th>';
       $resultat = $pdo->query("SELECT * FROM movies");
       while($movies = $resultat->fetch(PDO::FETCH_ASSOC))
       { 
           echo '<tr>';
           foreach ($movies as $key => $value) {
   
               echo '<th class="text-center">'.$value.'</th>';
   
           }
           
       }
       
    echo $content;
}


?>
<?php

require_once('inc/init.inc.php');

echo '<pre>' ; print_r($_POST); echo '</pre>';



if($_POST)
{
    //Rentrer les infos du film dans la BDD
    $resultat = $pdo->query("INSERT INTO movies (title, actors, director, producer, year_of_prod, language, category, storyline, video) VALUES ('$_POST[title]', '$_POST[actors]', '$_POST[director]', '$_POST[producer]', '$_POST[year_of_prod]', '$_POST[language]', '$_POST[category]', '$_POST[storyline]', '$_POST[video]')");

    echo '<div class="alert alert-success col-md-8 col-md-offset-2 text-center">Votre film a bien été ajouté !</div>
    </div>';

}




    


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <title>Formulaire 3</title>

    <style>

h1 {
    font-family: Calibri;
    background: #171356;
    padding : 10px;
    width: 500px;
    border-radius: 5px;
    text-align: center;
    color : #FFF;
}

label {
    float: left;
    width: 120px;
    font-style: italic;
    font-family: Calibri;
}

input, textarea {
    border-radius : 8px;
    padding: 3px;
    width: 400px
}

textarea {
    width: 400px;
    font-family: Calibri;
    height: 200px;
}

.submit {
    background: #171356;
    color: #FFF;
    width: 297px;
    height: 40px;
}

.error {
    color : white;
    background: red;
    padding : 10px;
    width: 230px;
    border-radius: 5px;
    text-align: center;
}

.ok {
    color : white;
    background: green;
    padding : 10px;
    width: 230px;
    border-radius: 5px;
    text-align: center;
}

</style>


</head>
<body>


<h1>Base de donnée de films !</h1>

<hr>

<form method="post" action="">

    <div class="form-group">
        <label for="title">Titre du film </label>
        <input type="text" id="title" name="title" placeholder="Titre du film" >
        <br><br>
    </div>

    <div class="form-group">
        <label for="actors">Acteurs </label>
        <input type="text" id="actors" name="actors" placeholder="Acteurs" >
        <br><br>
    </div>

    <div class="form-group">
        <label for="director">Réalisateur </label>
        <input type="text" id="director" name="director" placeholder="Réalisateur" >
        <br><br>
    </div>
    
    <div class="form-group">
        <label for="producer">Producteur </label>
        <input type="text" id="producer" name="producer" placeholder="Producteur" >
        <br><br>
    </div>

    <div class="form-group">
        <label for="year_of_prod">Année </label>
        <input type="text" id="year_of_prod" name="year_of_prod" placeholder="Année" >
        <br><br>
    </div>

    <div class="form-group">
        <label for="language">Langue </label>
        <input type="text" id="language" name="language" placeholder="Langue" >
        <br><br>
    </div>


    <div class="form-group">
    <label for="category">Genre, catégorie </label>
      <select class="form-group" id="category" name="category">
      <option value="action">Action</option>
      <option value="science_fiction">Science fiction</option>
      <option value="horreur">Horreur</option>
      <option value="comedie">Comédie</option>
      </select><br>

      <div class="form-group">
        <label for="storyline">Résumé </label>
        <textarea type="text" id="storyline" name="storyline" placeholder="Résumé" ></textarea>
        <br><br>
    </div>

    <div class="form-group">
        <label for="video">Lien vidéo </label>
        <input type="text" id="video" name="video" placeholder="Lien vidéo" >
        <br><br>

      <div class="form-group">
        <input type="submit" value="Envoyer" class="submit">

    </div>

</form>

   

  












    
</body>
</html>
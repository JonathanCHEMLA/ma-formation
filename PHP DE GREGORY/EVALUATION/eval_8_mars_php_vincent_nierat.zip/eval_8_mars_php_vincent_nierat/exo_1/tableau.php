<?php



$tab_infos = array( // je déclare les données du tableau array
    "Prénom" => "Vincent", 
    "Nom" => "Nierat", 
    "Adresse" => "6 avenue Diderot",
    "Code Postal" => "94100",
    "Ville" => "Saint Maur des Fossés",
    "Email" => "vincent@gmail.com",
    "Ville" => "Saint-Maur",
    "Téléphone" => "0612345678",
    "Date de naissance" => "1988-03-06" );
print_r($tab_infos); // J'affiche les données



echo "<table border=1><tr>"; // Je déclare mon tableau HTML  via "table, tr et th" dans lequel j'insert les données ci-dessus;
echo "<th>Données demandées</th>";
foreach($tab_infos as $indice => $valeur) // je déclare une boucle foreach pour parcourir l'ensemble du tableau array
{
    echo "<th>$indice</th>";
}
echo "</tr>";
echo "<th>Infos sur l'utilisateur</th>";
foreach($tab_infos as $indice => $valeur)
{
    echo "<th>$valeur</th>";
}
echo "</tr>";
echo "</table>"; // je ferme les balises du tableau

?>
<?php




$convert = file_get_contents('http://www.xe.com/ucc/convert.cgi?Amount=1&From=EUR&To=USD');
preg_match('`([0-9.]+) USD`i', $convert, $devise);
echo '1 euro vaut à ce jour '.$devise[1].' dollars Américains';





?>
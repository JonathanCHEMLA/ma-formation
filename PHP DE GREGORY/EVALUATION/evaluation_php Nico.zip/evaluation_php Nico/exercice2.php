<?php 

// Créer une fonction permettant de convertir un montant en euros vers un montant en dollars
// américains.
// Cette fonction prendra deux paramètres :
// - Le montant de type int ou float
// - La devise de sortie (uniquement EUR ou USD)

function conversion($montant, $devise) {  // j'appelle la fonction conversion qui a pour paramètres les variable $montant et $devise 
   
    if ($devise == 'EUR' OR $devise == 'USD' OR is_numeric($devise)){ //is_numeric permet de déterminer si la variable ($devise) est de type numérique
    
        if ($devise == 'EUR') {
            
            return $resultat = $montant * 1.085965 . '<br>' ;
        }   
        elseif ($devise == 'USD') {
            
            return $resultat = $montant * 0.805607025 . '<br>' ;
        }
        else {
                return 'Format invalide';    
        }
    }
} 
echo conversion(12,'USD');
echo conversion(135, 'EUR');
echo conversion(1250, 'USD');
echo conversion(22.5, 'EUR');

?>


<!--Exercice 3 
    
Cette table, nommée “movies” sera composée des champs suivants :
● title (varchar) : le nom du film
● actors (varchar) : les noms d’acteurs
● director (varchar) : le nom du réalisateur
● producer (varchar) : le nom du producteur
● year_of_prod (year) : l’année de production
● language (varchar) : la langue du film
● category (enum) : la catégorie du film
● storyline (text) : le synopsis du film
● video (varchar) : le lien de la bande annonce du film
N’oubliez pas de créer un ID pour chaque film et de l’auto-incrém -->

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exercice 3</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> <!--CDN bootstrap -->
</head>
<body>


<?php


if($_POST)
{
    // echo '<pre>'; print_r($_POST); echo '</pre>';
$pdo = new PDO ('mysql:host=localhost;dbname=exercice_3', 'root', '' , array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8')); // la classe prédéfinie $pdo permet de se connecter à notre BDD exercice_3

    $erreur = ''; // je déclare la variable erreur vide, si on rentre dans la condition elle apparaitra 
    $verif_title = $pdo->prepare("SELECT * FROM movies WHERE title =:title"); 
    $verif_title->bindValue(':title', $_POST['title'], PDO::PARAM_STR);
    $verif_title->execute();
    if($verif_title->rowCount() > 0)
    {
        $erreur .= 'Titre indisponible';
    }
    if(strlen($_POST['title'])< 5 || strlen($_POST['title'])> 40)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du titre non valide</div>';
  }
  if(strlen($_POST['actors'])< 5 || strlen($_POST['actors'])> 100)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du nom d\'acteursnon valide </div>';
  }
  if(strlen($_POST['director'])< 5 || strlen($_POST['director'])> 40)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du réalisateur non valide </div>';
  }
  if(strlen($_POST['producer'])< 5 || strlen($_POST['producer'])> 40)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille du producteur non valide </div>';
  }
  if(strlen($_POST['year_of_prod']< 5 || strlen($_POST['year_of_prod'])> 40) )
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Année non valide </div>';
  }
  if(strlen($_POST['language'])< 2 || strlen($_POST['language'])> 20)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Langue non valide </div>';
  }
  if(strlen($_POST['category'])< 2 || strlen($_POST['category'])> 20)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Catégorie non valide </div>';
  }
  if(strlen($_POST['storyline'])<2 || strlen($_POST['storyline'])>100)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">Taille de saisie non valide </div>';
  }
  if(strlen($_POST['video'])<3 || strlen($_POST['video'])>100)
  {
    $erreur.= '<div class="alert alert-danger col-md-8 col-md-offset-2 text-center">URL non valide </div>';
  }
  
  $content .= $erreur;  

  if(empty($erreur))
  
  
  {
// insérer un film dans la table movies de la BDD exercice_3
      
      $resultat = $pdo->prepare("INSERT INTO movies VALUES('$_POST[title]', '$_POST[actors]', '$_POST[director]', '$_POST[producer]', '$_POST[year_of_prod]', '$_POST[language]', '$_POST[category]', '$_POST[storyline]', '$_POST[video]')");

      $resultat->bindValue(':title', $_POST['title'], PDO::PARAM_STR);
      $resultat->bindValue(':actors', $_POST['actors'], PDO::PARAM_STR);
      $resultat->bindValue(':director', $_POST['director'], PDO::PARAM_STR);
      $resultat->bindValue(':producer', $_POST['producer'], PDO::PARAM_STR);
      $resultat->bindValue(':year_of_prod', $_POST['year_of_prod'], PDO::PARAM_STR);
      $resultat->bindValue(':language', $_POST['language'], PDO::PARAM_STR);
      $resultat->bindValue(':catégory', $_POST['category'], PDO::PARAM_STR);
      $resultat->bindValue(':storyline', $_POST['storyline'], PDO::PARAM_STR);
      $resultat->bindValue(':video', $_POST['video'], PDO::PARAM_STR);
      
      $resultat->execute();

      $content .= '<div class="alert alert-success col-md-8 col-md-offset-2 text-center">Vous venez d\'ajouter un film à notre collection !! <a href="connexion.php" class="alert-link">  </a></div>';

  }
  echo $content; 
  echo $resultat;
}


// echo "<table border =1><tr>"; //   TABLEAU
// echo"<th>POIDS</th>";

// foreach($_POST as $indice)
// {
//     echo "<th>[title]</th>";
// }
// echo '</tr>';
// foreach($ as $)
// {
//     echo '<tr>';
//     echo "<th>$ g </th>";
//     foreach ($ as $)
// {
//     echo '<td>'. calcul ($, $) . "</td>";

// }
// echo '<tr>';
// }
// echo '</table>';


?>

<!--**************Formulaire d'ajout de film à la BDD movies****************** -->

<form method="post" action="" class="formulaire col-md-6 col-md-offset-4">
<h1 class="alert alert-info text-center">Ajouter un film</h1>
  
  <div class="form-group">
    <label for="title">Titre</label>
    <input type="text" class="form-control" id="title" name="title">
  </div>
  <div class="form-group">
    <label for="actors">Acteurs</label>
    <input type="text" class="form-control" id="actors" name="actors">
  </div>
  <div class="form-group">
    <label for="director">Réalisateur</label>
    <input type="text" class="form-control" id="director" name="director">
  </div>
  <div class="form-group">
    <label for="producer">Producteur</label>
    <input type="text" class="form-control" id="producer" name="producer">
  </div>
  <div class="form-group">
    <label for="year_of_prod">Année de production</label>
    <input type="text" class="form-control" id="year_of_prod" name="year_of_prod">
    </select>
  </div>
  <div class="form-group">
    <label for="language">Langue</label>
    <select class="form-control" name="language">
    <option value="français">Français</option>
    <option value="espagnol">Espagnol</option>
    <option value="anglais">Anglais</option>
    <option value="italien">Italien</option>
    </select>
  </div>
  <div class="form-group">
    <label for="category">Catégorie</label>
    <select class="form-control" name="category" id="category">
    <option value= "horreur">Horreur</option>
    <option value="romantique">Romantique</option>
    <option value="action">Action</option>
    </select>
  </div>
  <div class="form-group">
    <label for="storyline">Synopsis</label>
    <input type="text" class="form-control" id="storyline" name="storyline">
  </div>
  <div class="form-group">
    <label for="video">Video</label>
    <input type="text" class="form-control" id="video" name="video">
  </div>
 
  <button type="submit" class="btn btn-block">Submit</button>
</form>


</body>
</html>

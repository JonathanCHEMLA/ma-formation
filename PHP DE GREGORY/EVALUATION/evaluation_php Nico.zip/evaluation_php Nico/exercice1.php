<!--Exercice 1 : « On se présente ! »
Créer un tableau en PHP contenant les infos suivantes :
● Prénom
● Nom
● Adresse
● Code Postal
● Ville
● Email
● Téléphone
● Date de naissance au format anglais (YYYY-MM-DD)
A l’aide d’une boucle, afficher le contenu de ce tableau (clés + valeurs) dans une liste HTML.
La date sera affichée au format français (DD/MM/YYYY).
Bonus :
Gérer l’affichage de la date de naissance à l’aide de la classe DateTime -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exercice 1 </title>
</head>
<body>


<?php

$presentation = array (
    'prenom' => 'Nicolas',
    'nom' => 'Durocher',
    'adresse' => '6 rue d\'Aumale',
    'code_postal' => '75009',
    'ville' => 'Rennes',
    'email' => 'ndurocher@hotmail.fr',
    'telephone' => '0680829161',
    'date_naissance' => '1992/01/20');

// echo '<pre>' ; print_r($presentation); echo '<pre>';
    
    echo '<ul>';
        foreach($presentation as $elements => $indice)
    {  
            echo '<li>' . $elements . ' : ' . $indice . '</li>';
    }       
    echo '</ul>';

    ?>


</body>
</html
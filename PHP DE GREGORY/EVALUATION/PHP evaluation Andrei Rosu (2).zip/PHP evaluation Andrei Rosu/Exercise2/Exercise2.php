<?php
/**
Exercice 2 : « On part en voyage »
Créer une fonction permettant de convertir un montant en euros vers un montant en dollars
américains.
Cette fonction prendra deux paramètres :
● Le montant de type int ou float
● La devise de sortie (uniquement EUR ou USD).
Si le second paramètre est “USD”, le résultat de la fonction sera, par exemple :
1 euro = 1.085965 dollars américains
Il faut effectuer les vérifications nécessaires afin de valider les paramètres.
 */?>
<html>
<head>
    <style>
        #box
        {
            width:350px;
            height:270px;
            margin:0 auto;
            border:2px solid black;
        }
        h2{
            text-align: center;
        }
        table{
            margin:0 auto;
        }
        form{
            text-align: center;
        }
    </style>
</head>

<body>

<form action="Exercise2.php" method="post">

    <div id="box">
        <h2>Converteur</h2>
        <table>
            <tr>
                <td>
                    <label for="cantité">Cantité:</label>
                    <input type="text" id="cantité" name="cantite"><br>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="de">De:</label>
                    <select name='cur1' id="de">
                        <option value="EUR">Euro(€)</option>
                            <option value="USD" selected>US Dollar($)</option>
                        </select>
                </td>
            </tr>
            <tr>
                <td>
                    <br><label for="A">A:</label>
                    <select name='cur2' id="A">
                            <option value="EUR" selected >Euro(€)</option>
                            <option value="USD">US Dollar($)</option>


                        </select>
                </td>
            </tr>
            <tr>
                <td><br>
                    <label for="submit">Convertir</label>
                        <input type='submit' name='submit' value="Conversion"></center>
                </td>
            </tr>
        </table>
</form>
<?php
if(isset($_POST['submit'])){

    $cantite = $_POST['cantite'];
    $cur1 = $_POST['cur1'];
    $cur2 = $_POST['cur2'];


    if($cur1=="EUR" AND $cur2=="USD"){
        echo "<b>Le total de la conversion est:</b><br>";
        echo  $cantite*1.085965;
    }

    if($cur1=="USD" AND $cur2=="EUR"){
        echo "<b>Le total de la conversion est:</b><br>";
        echo $cantite*0.92;
    }

    if($cur1=="EUR" AND $cur2=="EUR"){
        echo "<b>Choisir une devise differente</b><br>";
    }

    if($cur1=="USD" AND $cur2=="USD"){
        echo "<b>Choisir une devise differente</b><br>";
    }




}

?>

</body>
</html>






<html>
<head>
    <title>Temp Conversion</title>
    <meta charset="utf-8">
</head>
<body>
<form name="tempConvert" method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

    <table>
        <tr>
            <td>Enter value to convert</td>
            <td><input type="text" name="valueConvert" id="valueConvert" size="15"></td>
        </tr>

        <tr>
            <td>Convert to:</td>
            <td><select name="convertType" id="convertType" size="1">
                    <option disabled> Select a measurement type</option>
                    <option value="celsius">Celsius</option>
                    <option value="fahrenheit">Fahrenheit</option>
                </select>
            </td>
        </tr>

        <tr>
            <td><input type="submit" name="btnConvert" id="btnConvert" value="Convert"></td>
            <td><input type="reset" name="btnReset" id="btnReset" value="Reset"></td>
        </tr>



</form>

<?php
function tempConvert($value, $type){
    if($type== "fahrenheit"){
        return (((9/5)*$value) +(32));
    }
    elseif ($type== "celsius"){
        return (($valueConvert - 32) * (9/5));
    }
}

if (isset($_POST['btnConvert'])) {
    $valueConvert = $_POST['valueConvert'];
    $convertType = $_POST['convertType'];

    echo "The initial temperature was $valueConvert. The new temperature is tempConvert($valueConvert, $convertType).";
}
?>

</body>
</html>
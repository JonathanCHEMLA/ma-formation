-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 08 mars 2018 à 14:34
-- Version du serveur :  10.1.26-MariaDB
-- Version de PHP :  7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `exercise3`
--

-- --------------------------------------------------------

--
-- Structure de la table `movies`
--

CREATE TABLE `movies` (
  `id_movie` int(100) NOT NULL,
  `title` varchar(20) NOT NULL,
  `actors` varchar(500) NOT NULL,
  `director` varchar(100) NOT NULL,
  `producer` varchar(100) NOT NULL,
  `year` year(4) NOT NULL,
  `language` varchar(20) NOT NULL,
  `category` enum('action','comedy','drama','epic') NOT NULL,
  `story_line` varchar(1000) NOT NULL,
  `video` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `movies`
--

INSERT INTO `movies` (`id_movie`, `title`, `actors`, `director`, `producer`, `year`, `language`, `category`, `story_line`, `video`) VALUES
(3, 'The Godfather', 'Al Pacino', 'Francis Ford Coppola', 'Albert S. Ruddy', 1972, 'en', 'action', 'Le meilleur', ''),
(4, 'Silence of the Lambs', 'Jodie Foster, Anthony Hopkins, and Scott Glenn', 'Jonathan Demme', ' ‎Kenneth Utt‎', 1991, 'en', 'drama', 'A young F.B.I. cadet must receive the help of an incarcerated and manipulative cannibal killer to help catch another serial killer, a madman who skins his victims.', 'https://www.youtube.com/watch?v=zeKqD2g9-ic'),
(5, 'The Legend of 1900', 'Tim Roth Pruitt Taylor Vince, Mélanie Thierry ,Bill Nunn', 'Giuseppe Tornatore ', 'Francesco Tornatore', 1998, 'en', 'drama', 'The story is told in medias res as a series of flashbacks. Max Tooney, a musician, enters a secondhand music shop just before closing time, broke and badly in need of money. ', 'https://www.youtube.com/watch?v=wOfGsKUfAq4'),
(6, 'The Legend of 1900', 'Tim Roth Pruitt Taylor Vince, Mélanie Thierry ,Bill Nunn', 'Giuseppe Tornatore ', 'Francesco Tornatore', 1998, 'en', 'drama', 'The story is told in medias res as a series of flashbacks. Max Tooney, a musician, enters a secondhand music shop just before closing time, broke and badly in need of money. ', 'https://www.youtube.com/watch?v=wOfGsKUfAq4'),
(7, 'The Legend of 1900', 'Tim Roth Pruitt Taylor Vince, Mélanie Thierry ,Bill Nunn', 'Giuseppe Tornatore ', 'Francesco Tornatore', 1998, 'en', 'drama', 'The story is told in medias res as a series of flashbacks. Max Tooney, a musician, enters a secondhand music shop just before closing time, broke and badly in need of money. ', 'https://www.youtube.com/watch?v=wOfGsKUfAq4'),
(8, 'The Legend of 1900', 'Tim Roth Pruitt Taylor Vince, Mélanie Thierry ,Bill Nunn', 'Giuseppe Tornatore ', 'Francesco Tornatore', 1998, 'en', 'drama', 'The story is told in medias res as a series of flashbacks. Max Tooney, a musician, enters a secondhand music shop just before closing time, broke and badly in need of money. ', 'https://www.youtube.com/watch?v=wOfGsKUfAq4'),
(9, 'The Legend of 1900', 'Tim Roth Pruitt Taylor Vince, Mélanie Thierry ,Bill Nunn', 'Giuseppe Tornatore ', 'Francesco Tornatore', 1998, 'en', 'drama', 'The story is told in medias res as a series of flashbacks. Max Tooney, a musician, enters a secondhand music shop just before closing time, broke and badly in need of money. ', 'https://www.youtube.com/watch?v=wOfGsKUfAq4'),
(10, 'The Legend of 1900', 'Tim Roth Pruitt Taylor Vince, Mélanie Thierry ,Bill Nunn', 'Giuseppe Tornatore ', 'Francesco Tornatore', 1998, 'en', 'drama', 'The story is told in medias res as a series of flashbacks. Max Tooney, a musician, enters a secondhand music shop just before closing time, broke and badly in need of money. ', 'https://www.youtube.com/watch?v=wOfGsKUfAq4');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id_movie`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `movies`
--
ALTER TABLE `movies`
  MODIFY `id_movie` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
/**
 * Exercice 3 : « Et si on regardait un film ? »
Vous travaillez pour un cinéma et devez créer une base de données de film. Votre base de
données s’appellera « exercice_3 ». Vous devrez ensuite créer un script qui permettra
d’ajouter et d’afficher des films. Suivez les étapes.
 *
Étape 1 :
Cette table, nommée “movies” sera composée des champs suivants :
● title (varchar) : le nom du film
● actors (varchar) : les noms d’acteurs
● director (varchar) : le nom du réalisateur
● producer (varchar) : le nom du producteur
● year_of_prod (year) : l’année de production
● language (varchar) : la langue du film
● category (enum) : la catégorie du film
● storyline (text) : le synopsis du film
● video (varchar) : le lien de la bande annonce du film
N’oubliez pas de créer un ID pour chaque film et de l’auto-incrémenter.
 *
Étape 2 :
 *
Créer un formulaire permettant d’ajouter un film et effectuer les vérifications nécessaires.
Prérequis :
● Les champs “titre, nom du réalisateur, acteurs, producteur et synopsis” comporteront
au minimum 5 caractères.
● Les champs : année de production, langue, category, seront obligatoirement un
menu déroulant
● Le lien de la bande annonce sera obligatoirement une URL valide
● En cas d’erreurs de saisie, des messages d’erreurs seront affichés en rouge
Chaque film sera ajouté à la base de données créée. Un message de réussite confirmera
l’ajout du film.

Étape 3 :
Créer une page listant dans un tableau HTML les films présents dans la base de données.
Ce tableau ne contiendra, par film, que le nom du film, le réalisateur et l’année de
production.
Une colonne de ce tableau contiendra un lien « plus d’infos » permettant de voir la fiche
d’un film dans le détail.
Étape 4 :
Créer une page affichant le détail d’un film de manière dynamique. Si le film n’existe pas,
une erreur sera affichée.
 */
//---------- CONNEXION BDD
$pdo = new PDO('mysql:host=localhost;dbname=exercise3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

//---------- SESSION
session_start();

//---------- CHEMIN
define("RACINE_SITE", $_SERVER['DOCUMENT_ROOT'] . "/PHP evaluation/Exercise3/");
// cette constante retourne le chemin physique du dossier boutique sur le serveur
// lors de l'enregistrement d'image/photos , nous aurons du chemin complet du dossier photo pour enregistrer la photo
//echo '<pre>'; print_r($_SERVER); echo '</pre>';
//echo RACINE_SITE;

define("URL", 'http://localhost/PHP/boutique/');
// cette constante servira à enregister l'URL d'une photo/image dans la BDD, on ne conserve jamais la photo elle même, ce serait trop lourd pour la BDD


$content = '';
?>
<?php
if($_POST)
{
    $erreur = '';


    if(strlen($_POST['title']) < 2)
    {
        $erreur .= 'taille du titre non valide !!';
    }
    if(strlen($_POST['director']) < 5)
    {
        $erreur .= 'taille de nom du réalisateur non valide !!';
    }
    if(strlen($_POST['actors']) < 5)
    {
        $erreur .= 'taille du nom acteur non valide !!';
    }
    if(strlen($_POST['producer']) < 5)
    {
        $erreur .= 'taille du nom producteur non valide !!';
    }
    if(strlen($_POST['story_line']) < 5)
    {
        $erreur .= 'taille du synopsis non valide !!';
    }

    $content .= $erreur;

    if(empty($erreur))
    {
        // Exercice : réaliser le script permettant de s'insérer dans la table membre à l'aide d'une requete préparée
        //$_POST['mdp'] = password_hash($_POST['mdp'], PASSWORD_DEFAULT);// on ne conserve jamais les mots de passe en clair dans la BDD, password_hash permet de hacher le mot de passe en algorithme

        $resultat = $pdo->prepare("INSERT INTO movies (title,director,actors,producer,year,language,category,story_line,video) VALUES (:title,:director,:actors,:producer,:year,:language,:category,:story_line,:video)");

        $resultat->bindValue(':title', $_POST['title'], PDO::PARAM_STR);
        $resultat->bindValue(':director', $_POST['director'], PDO::PARAM_STR);
        $resultat->bindValue(':actors', $_POST['actors'], PDO::PARAM_STR);
        $resultat->bindValue(':producer', $_POST['producer'], PDO::PARAM_STR);
        $resultat->bindValue(':year', $_POST['year'], PDO::PARAM_INT);
        $resultat->bindValue(':language', $_POST['language'], PDO::PARAM_STR);
        $resultat->bindValue(':category', $_POST['category'], PDO::PARAM_STR);
        $resultat->bindValue(':story_line', $_POST['story_line'], PDO::PARAM_INT);
        $resultat->bindValue(':video', $_POST['video'], PDO::PARAM_STR);

        $resultat->execute();

        $content .= 'Vous avez bien ajouté un film <a href="liste.php?action=affichage" >Cliquez ici pour voir la liste des films</a></div>';

    }
}
echo $content;
?>


<form method="post" action="" >
    <h1 >Ajouter un film</h1>
    <label for="title">Titre</label>
        <input type="text"  id="title" name="title" placeholder="Titre">
    <label for="director">Réalisateur</label>
        <input type="text"  id="director" name="director" placeholder="Réalisateur">
    <label for="actors">Acteurs</label>
        <input type="text" id="actors" name="actors" placeholder="Acteurs">
    <label for="producer">Producteur</label>
        <input type="text" id="producer" name="producer" placeholder="Producteur">
    <label for="year">Année de production</label>
    <?php
    $Startyear=date('Y');
    $endYear=$Startyear-80;

    // set start and end year range i.e the start year
    $yearArray = range($Startyear,$endYear);
    ?>
    <select name="year">
        <option value="">Select Year</option>
        <?php
        foreach ($yearArray as $year) {
            // this allows you to select a particular year
            $selected = ($year == $Startyear) ? 'selected' : '';
            echo '<option '.$selected.' value="'.$year.'">'.$year.'</option>';
        }
        ?>
    </select>
    <label for="language">Civilité</label>
        <select  id="language" name="language">
            <option value="en">Anglais</option>
            <option value="fr">Français</option>
            <option value="es">Espagnol</option>
        </select>
    </select>
    <label for="category">Categorie</label>
    <select  id="category" name="category">
        <option value="action">Action</option>
        <option value="comedy">Comédie</option>
        <option value="drama">Drame</option>
        <option value="epic">Epique</option>
    </select>


        <label for="story_line">Ville</label>
        <input type="text"  id="story_line" name="story_line" placeholder="Synopsis">


        <label for="video">Video</label>
        <input type="text"  id="video" name="video" placeholder="Video">


    <button type="submit">Ajouter un produit</button>
</form>
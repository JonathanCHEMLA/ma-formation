<?php
//---------- CONNEXION BDD
$pdo = new PDO('mysql:host=localhost;dbname=exercise3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

//---------- SESSION
session_start();

//---------- CHEMIN
define("RACINE_SITE", $_SERVER['DOCUMENT_ROOT'] . "/PHP evaluation/Exercise3/");
// cette constante retourne le chemin physique du dossier boutique sur le serveur
// lors de l'enregistrement d'image/photos , nous aurons du chemin complet du dossier photo pour enregistrer la photo
//echo '<pre>'; print_r($_SERVER); echo '</pre>';
//echo RACINE_SITE;

define("URL", 'http://localhost/PHP/boutique/');
// cette constante servira à enregister l'URL d'une photo/image dans la BDD, on ne conserve jamais la photo elle même, ce serait trop lourd pour la BDD


$content = '';
?>


<?php

if(isset($_GET['action']) && $_GET['action'] == 'affichage')
{

$resultat = $pdo->query("SELECT * FROM movies");



$content .= '<table style="margin-top: 10px;"><tr>';
        for($i = 0; $i < $resultat->columnCount(); $i++)
        {
        $colonne = $resultat->getColumnMeta($i);
        $content .= '<th>' . $colonne['name'] . '</th>';
        }
        $content .= '<th>Modification</th>';
        $content .= '<th>Suppression</th>';
        $content .= '</tr>';

}
?>